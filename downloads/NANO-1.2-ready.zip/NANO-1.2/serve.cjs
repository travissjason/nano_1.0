const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const { exec } = require("node:child_process");
const html = fs.readFileSync(path.join(__dirname, "NANO.html"));
const server = http.createServer((req, res) => {
  if (!["/", "/NANO.html"].includes(req.url)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
  res.end(html);
});
server.on("error", error => { console.error(error.message); process.exitCode = 1; });
server.listen(0, "127.0.0.1", () => {
  const url = `http://127.0.0.1:${server.address().port}`;
  console.log(`NANO 1.2: ${url}\nKeep this window open. Press Ctrl+C to stop.`);
  if (process.platform === "win32") exec(`start "" "${url}"`);
});
